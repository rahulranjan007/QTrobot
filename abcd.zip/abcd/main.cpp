#include "Widget.h"
#include <QApplication>
#include <QQuickView>
#include <QQuickItem>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //a.setStyle("fusion");

    QQuickView view;

    view.setSource(QUrl::fromLocalFile("main.qml"));

    QQuickItem *pQMLRectangle = view.rootObject();//Returns the view's root item (item here means basic Qt Quick element)
    //MyObject *pMyObject = new MyObject();
     Widget *pWidget= new Widget();

     QObject::connect(
                 pQMLRectangle,
                 SIGNAL ( qmlBack ( QString ) ),
                 pWidget,
                 SLOT (on_backPushButton_clicked( QString ) )
                 );
     QObject::connect(
                 pQMLRectangle,
                 SIGNAL ( qmlFront ( QString ) ),
                 pWidget,
                 SLOT (on_frontPushButton_clicked( QString ) )
                 );
     QObject::connect(
                 pQMLRectangle,
                 SIGNAL ( qmlLeft ( QString ) ),
                 pWidget,
                 SLOT (on_leftPushButton_clicked( QString ) )
                 );
     QObject::connect(
                 pQMLRectangle,
                 SIGNAL ( qmlRight ( QString ) ),
                 pWidget,
                 SLOT (on_rightPushButton_clicked( QString ) )
                 );
     QObject::connect(
                 pQMLRectangle,
                 SIGNAL ( qmlStop ( QString ) ),
                 pWidget,
                 SLOT (on_stopPushButton_clicked( QString ) )
                 );


    view.show();
    return a.exec();
}
