#include<QObject>
#include <QWidget>
#include<QDebug>
class QSerialPort;

class Widget : public QWidget
{
    Q_OBJECT
public:
Widget();
private slots:

    void on_frontPushButton_clicked(QString );
    void on_backPushButton_clicked( QString );
    void on_rightPushButton_clicked(QString );
    void on_leftPushButton_clicked(QString );
   void on_stopPushButton_clicked(QString );


private:
    //Ui::Widget *ui;
    QSerialPort *arduino;
    static const quint16 arduino_uno_vendor_id = 9025;
    static const quint16 arduino_uno_product_id = 67;
    QString arduino_port_name;
    bool arduino_is_available;
};


